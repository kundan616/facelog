<?php
session_start();
include('config.php');
// Validating Session
if(strlen($_SESSION['userlogin'])==0)
{
header('location:index.php');
}
else{
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title> Welcome Page</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/css/bootstrap-combined.min.css" rel="stylesheet">
    <style type="text/css">
          .center {text-align: center; margin-left: auto; margin-right: auto; margin-bottom: auto; margin-top: auto;}
    </style>
    <script src="https://code.jquery.com/jquery-1.11.1.min.js"></script>
    <script src="https://netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container">
  <div class="row">
    <div class="span12">
	<div style="float:right;"> <a href="logout.php" class="btn btn-large btn-info"><i class="icon-home icon-white"></i> Log me out</a> </div>
      <div class="hero-unit center">
	 
<br>
<?php
// Code for fecthing user full name on the bassis of username or email.
$username=$_SESSION['userlogin'];
$query=$dbh->prepare("SELECT  FullName FROM userdata WHERE (UserName=:username || UserEmail=:username)");
      $query->execute(array(':username'=> $username));
       while($row=$query->fetch(PDO::FETCH_ASSOC)){
        $username=$row['FullName'];
       }
       ?>
          <h3 >Welcome Back <font face="Tahoma" color="red"><?php echo $username;?> ! </font></h3>
		  
                          <center>  <h2>   Menu                </h2>   </center>
          <p>
		  <ul style="list-style-type:none">
		<li><a href="details_filling.php">  Your Profile  </a> </li>
		<li><a href="matches.php">  Your Matches  </a> </li>
		<li><a href="peoples.php">  Meet People </a> </li>
		<li><a href="users/account.php">  Account  </a> </li>
		<li><a href="details_filling.php">  About us  </a> </li>

		</ul>
          </p>
          
        </div>

      </div>
   
       
    </div>
  </div>
</div>
<script type="text/javascript">
</script>
</body>
</html>
<?php } ?>