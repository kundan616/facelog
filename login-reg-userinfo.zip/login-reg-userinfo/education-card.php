<?php
session_start();
include('config.php');
// Validating Session
$username=$_SESSION['userlogin'];

	   
//echo $username;
if(strlen($_SESSION['userlogin'])==0)
{
header('location:index.php');
}
else{

if(isset($_POST['submit']))
{
	$school=$_POST['school'];
	$ug_degree=$_POST['ug_degree'];
	$ug_college=$_POST['ug_college'];
	$pg_degree=$_POST['pg_degree'];
	$pg_college=$_POST['pg_college'];
$username=$_SESSION['userlogin'];
$query=$dbh->prepare("INSERT INTO users_education (user_login,school_name,ug_degree,ug_institute,pg_degree,pg_institute) VALUES ('$username','$school', '$ug_degree', '$ug_college','$pg_degree','$pg_college') ");
      $query->execute();
	  	if($query){
			echo ' data saved';
		}
	else{
		echo 'there is an error';
	}
	
	
}	
}
	?>
<html>
<head>

<title>         Let Us Begin To Know You         </title>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/webcamjs/1.0.25/webcam.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">


</head>
<body>

<h2 style="text-align:center;">            Let Us Build Your Education Card                                     </h2>
<div style="width:50%;margin-left:150px;">
<form action="" method="post">
<div class="form-group">
<label>       School               </label> <br>
<input type="text" class="form-control " placeholder="Enter Your School name" name="school" required >
<br>

<label>       Under-Graduation degree               </label> <br>
<input type="text" name="ug_degree"   placeholder="Enter Your UG Degree name" class="form-control " required >
<br>
<label>         UG College            </label> <br>
<input type="text" name="ug_college"   placeholder="Enter Your UG College name" class="form-control " required >
<br>

<label>       Post-Graduation Degree </label> <br>
<input type="text" name="pg_degree"  class="form-control "  placeholder="Enter Your PG Degree Name" required >
<br>
<label>        PG College           </label> <br>
<input type="text" name="pg_college"  class="form-control "  placeholder="Enter Your PG College name" required >

<br>
<center><input type="submit" class="btn btn-info" name="submit"  value="Next"> </center>
</div>







</form>
</div>

</body>
</html>
