<?php
session_start();
include('config.php');
// Validating Session
$username=$_SESSION['userlogin'];

	   
//echo $username;
if(strlen($_SESSION['userlogin'])==0)
{
header('location:index.php');
}
//$username=$_SESSION['userlogin'];


else{

if(isset($_POST['submit']))
{
	$gender1=$_POST['mine_gender'];
	$gender2=$_POST['others_gender'];
	$height=$_POST['person_height'];
	$build=$_POST['bulid'];
	$complexion=$_POST['complexion'];
	$dob=$_POST['dob'];
	$drinks=$_POST['drinks'];
	$smoke=$_POST['smoke'];
	$smokeup=$_POST['smokeup'];
	$children=$_POST['children'];
	$salary=$_POST['salary'];
	$education=$_POST['education'];
	$martial_status=$_POST['martial_status'];
	$hometown=$_POST['hometown'];
//$username=$_SESSION['userlogin'];
$query=$dbh->prepare("INSERT INTO userinfo (user_login,users_gender,looking_gender,person_height,build,complexion,dob,drink,smoke,smokeup,children,salary,education,
martial_status,hometown) VALUES ('$username','$gender1', '$gender2', '$height','$build','$complexion','$dob','$drinks','$smoke','$smokeup','$children',
'$salary','$education','$martial_status','$hometown') ");
      $query->execute();
      echo "saved";  
}
$username=$_SESSION['userlogin'];
$query=$dbh->prepare("SELECT * FROM userinfo WHERE user_login=:username");
      $query->execute(array(':username'=> $username));
       while($row=$query->fetch(PDO::FETCH_ASSOC)){
        
		 $user=$row['user_login'];
       
 if(strlen($user)!==0){
header('location:profile.php');
		   
	   }
	   }

	   
?>

<html>
<head>


<title>     Users Details.php                        </title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/webcamjs/1.0.25/webcam.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
<script>
function validate(evt) {
  var theEvent = evt || window.event;

  // Handle paste
  if (theEvent.type === 'paste') {
      key = event.clipboardData.getData('text/plain');
  } else {
  // Handle key press
      var key = theEvent.keyCode || theEvent.which;
      key = String.fromCharCode(key);
  }
  var regex = /[0-9]|\./;
  if( !regex.test(key) ) {
    theEvent.returnValue = false;
    if(theEvent.preventDefault) theEvent.preventDefault();
  }
}
</script>

</head>
<body>
<center>
<h1>         Lets us Begin To Know You     </h1>
<form action="" method="post">

<label>I am </label> <br>

<select name="mine_gender" id="mine_gender"  required>
<option value="">  Please Select                   </option>
<option value="male">  MALE                       </option>
<option value="female">  FEMALE                      </option>


</select>
<br>
<label>Looking For </label> <br>

<select name="others_gender" id="others_gender"  required>
<option value="">  Please Select                   </option>
<option value="female">  FEMALE                      </option>
<option value="male">  MALE                       </option>



</select>
<br>
<?php
function personHeightOptions(){
  $itotal = 95; $r = '';
  for($foot=7;$foot>=4;$foot--){
      for($inches=11;$inches>=0;$inches--){
          if($inches==0){
             $r .= "<option value='$itotal'> $foot' 0\" </option>";
           }else{
             $r .= "<option value='$itotal'> $foot' $inches\" </option>";
           }
  $itotal--;
      }
  }
 return $r;
}
?>
<label>Height in Feet'Inches </label>
<br>

<select name="person_height" id="person_height">
  <option disabled selected>Height</option>
  <?php echo  personHeightOptions(); ?>
</select>
<br>
<label>Bulid </label> <br>

<select name="bulid" id="bulid"  required>
<option value="">  Please Select                   </option>
<option value="slim">  Slim                     </option>
<option value="medium">  Medium                      </option>
<option value="heavy">  Heavy                    </option>


</select>


<br>
<label>Complexion </label> <br>

<select name="complexion" id="bulid"  required>
<option value="">  Please Select                   </option>
<option value="fair">  Fair                     </option>
<option value="veryfair">  Very Fair                     </option>
<option value="wheatish">  Wheatish                   </option>
<option value="dusky">  Dusky                    </option>
<option value="dark">  Dark                  </option>

</select>
<br>

<label>Date Of Birth         </label>
<br>
<input type="date" placeholder="mm/dd/yyyy" name="dob" id="dob">
<br>
<label>Drinks </label> <br>

<select name="drinks" id="drinks"  required>
<option value="">  Please Select                   </option>
<option value="yes">  Yes                   </option>
<option value="sometimes">  Sometimes                 </option>
<option value="no">  No                    </option>



</select>
<br>
<label>Smoke </label> <br>

<select name="smoke" id="smoke"  required>
<option value="">  Please Select                   </option>
<option value="yes">  Yes                   </option>
<option value="sometimes">  Sometimes                 </option>
<option value="no">  No                    </option>



</select>
<br>

<label>Smoke-up </label> <br>

<select name="smokeup" id="smokeup"  required>
<option value="">  Please Select                   </option>
<option value="yes">  Yes                   </option>
<option value="sometimes">  Sometimes                 </option>
<option value="no">  No                    </option>



</select>
<br>
<label>Highest Education  </label> <br>

<select name="education" id="education"  required>
<option value="">  Please Select                   </option>
<option value="graduate">  Graduate                  </option>
<option value="postgraduate">  Post Graduate                 </option>
<option value="doctorate">  Doctorate                  </option>



</select>
<br>
<label>Income Per Months  INR    </label>
<br>
<input type='text' onkeypress='validate(event)'  name="salary" id="salary"/>

<br>

<label>Want Children </label> <br>

<select name="children" id="children"  required>
<option value="">  Please Select                   </option>
<option value="yes">  Yes                   </option>
<option value="notdecided">  Not Decided                 </option>
<option value="no">  No                    </option>



</select>
<br>
<label>Martial Status </label> <br>

<select name="martial_status" id="children"  required>
<option value="">  Please Select                   </option>
<option value="single">  Single                  </option>
<option value="divorced">  Divorced                 </option>
<option value="windowed"> Windowed                    </option>
<option value="separated"> Separated                   </option>


</select>
<br>
<label>HomeTown </label> <br>
<input type="text" placeholder="hometown" name="hometown" id="hometown" required>
<br>
<br>
<input type="submit" name="submit" id="submit" value="saveinformation"/>

</center>









</form>

</html>
<?php
	   
}
?>
