<?php
include('../config.php');
    session_start();
    $img = $_POST['image'];
    $folderPath = "upload/";
  
    $image_parts = explode(";base64,", $img);
    $image_type_aux = explode("image/", $image_parts[0]);
    $image_type = $image_type_aux[1];
  
    $image_base64 = base64_decode($image_parts[1]);
    $fileName = uniqid() . '.png';
  
    $file = $folderPath . $fileName;
    file_put_contents($file, $image_base64);
  
   
  
?>

<?php
// Code for fecthing user full name on the bassis of username or email.
$username=$_SESSION['userlogin'];
$query=$dbh->prepare("UPDATE  userdata SET users_snapshot='$fileName' WHERE (UserName=:username || UserEmail=:username)");
      $query->execute(array(':username'=> $username));
      header('location:../welcome.php'); 
       ?>