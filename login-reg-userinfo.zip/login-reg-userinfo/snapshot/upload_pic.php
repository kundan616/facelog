<html>
	
<?php
include('../config.php');
    session_start();
  if (isset($_POST['add'])) {
if (($_FILES['my_file']['name']!="")){
    
	$target_dir = "upload/";
	$file = $_FILES['my_file']['name'];
	$path = pathinfo($file);
	$filename = $path['filename'];
	$ext = $path['extension'];
	$temp_name = $_FILES['my_file']['tmp_name'];
	$path_filename_ext = $target_dir.$filename.".".$ext;
     
}
if (file_exists($path_filename_ext)) {
 echo "Sorry, file already exists.";
 }else{
 move_uploaded_file($temp_name,$path_filename_ext);
 echo "Congratulations! File Uploaded Successfully.";
 }
  }
  
?>


<?php 


  if (isset($_POST['add'])) {
  	
       //	$contact = $_POST['contact'];
		
         

$username=$_SESSION['userlogin'];
$query=$dbh->prepare("UPDATE  userdata SET users_uploadedpic='$path_filename_ext' WHERE (UserName=:username || UserEmail=:username)");
      $query->execute(array(':username'=> $username));
      echo "saved";     
  	
  }
?>

<body >

                        <div class="card-body" style="padding-bottom:0;">
                          <div class="row">
						  <form action="" method="post" enctype="multipart/form-data">
                            

                            <div class="col-md col-12 mb-3">
                              <input type="file" id="my_file" name="my_file" />
				              </div>
                                <div class="col-md col-12 mb-3">
                                    <button  type="submit" name="add" id="add" class="btn btn-primary form-control">Add</button>
                                  </div>
								  </form>
                          </div>
                        </div>
                    
					
					
</body>		
		</html>