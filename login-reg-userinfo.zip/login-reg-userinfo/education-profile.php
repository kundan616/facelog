<html>
<head>



<title>     User's Education Details                                                </title>
                   


<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/webcamjs/1.0.25/webcam.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">



</head>

<body>
<?php
session_start();
include('config.php');
// Code for fecthing user full name on the bassis of username or email.
$username=$_SESSION['userlogin'];
$query=$dbh->prepare("SELECT * FROM users_education WHERE user_login=:username");
      $query->execute(array(':username'=> $username));
       while($row=$query->fetch(PDO::FETCH_ASSOC)){
        $school_name=$row['school_name'];
		$ug_degree=$row['ug_degree'];
         $pg_degree=$row['pg_degree'];
$ug_institute=$row['ug_institute'];
$pg_institute=$row['pg_institute'];		 
       }
       ?>

 
              <h2 style="text-align:center;"> My   Education Details    </h2>
          <div class="row" style="margin-left:100px; ">
            <div class="col-4"  >
			<p>
			<h4>  School                 </h4>
			<strong>   <?php   echo $school_name;             ?>    </strong>
			</p>
			<br>
			<p>
			<h4>  UG Degree                </h4>
			<strong>   <?php   echo $ug_degree;             ?>    </strong>
			</p>
			<br>
			<p>
			<h4>  Ug Institution                 </h4>
			<strong>   <?php   echo $ug_institute;             ?>    </strong>
			</p>
			<br>
			<p>
			<h4>  PG Degree                 </h4>
			<strong>   <?php   echo $pg_degree;             ?>    </strong>
			</p>
           <br>				
				<p>
			<h4>  PG Institution                 </h4>
			<strong>   <?php   echo $pg_institute;             ?>    </strong>
			</p>
			
			
			
			</div>

</div>








</body>
</html>