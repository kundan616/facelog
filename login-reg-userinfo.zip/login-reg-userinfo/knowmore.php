<?php
session_start();
include('config.php');
// Validating Session
$username=$_SESSION['userlogin'];

	   
//echo $username;
if(strlen($_SESSION['userlogin'])==0)
{
header('location:index.php');
}
else{

if(isset($_POST['submit']))
{
	$lhappens=$_POST['lhappens'];
	$marriageis=$_POST['marriageis'];
	$favcouple=$_POST['favcouple'];
	$favrommovie=$_POST['favrommovie'];
	$ris=$_POST['ris'];
$username=$_SESSION['userlogin'];
$query=$dbh->prepare("INSERT INTO usersanswers (user_login,lhappens,marriageis,favcouple,myrommovie,romis) VALUES ('$username','$lhappens', '$marriageis', '$favcouple','$favrommovie','$ris') ");
      $query->execute();
	  if($query){
      header('location:partner-prefernces.php');  
}
else{
	echo "there is an error";
}	
	
	
	
}	
}
	?>
<html>
<head>

<title>         Let Us Begin To Know You         </title>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/webcamjs/1.0.25/webcam.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">


</head>
<body>

<h2 style="text-align:center;">            Let Us Begin To Know You  More                                    </h2>
<div style="width:50%;margin-left:150px;">
<form action="" method="post">
<div class="form-group">
<label>       Love Happens When                </label> <br>
<input type="text" class="form-control " name="lhappens" required >
<br>

<label>       Marriage is               </label> <br>
<input type="text" name="marriageis"  class="form-control " required >
<br>
<label>       My Favorite  Couple              </label> <br>
<input type="text" name="favcouple"  class="form-control " required >
<br>

<label>       My Favorite Romantic Movie             </label> <br>
<input type="text" name="favrommovie"  class="form-control " required >
<br>
<label>        Romance is            </label> <br>
<input type="text" name="ris"  class="form-control " required >

<br>
<center><input type="submit" class="btn btn-info" name="submit"  value="Next"> </center>
</div>







</form>
</div>

</body>
</html>
