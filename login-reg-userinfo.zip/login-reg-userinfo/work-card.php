<?php
session_start();
include('config.php');
// Validating Session
$username=$_SESSION['userlogin'];

	   
//echo $username;
if(strlen($_SESSION['userlogin'])==0)
{
header('location:index.php');
}
else{

if(isset($_POST['submit']))
{
	$profession=$_POST['profession'];
	$organization=$_POST['organization'];
	$designation=$_POST['designation'];
	$location=$_POST['location'];
	$income=$_POST['income'];
$username=$_SESSION['userlogin'];
$query=$dbh->prepare("INSERT INTO users_education (user_login,school_name,ug_degree,ug_institute,pg_degree,pg_institute) VALUES ('$username','$school', '$ug_degree', '$ug_college','$pg_degree','$pg_college') ");
      $query->execute();
	  	if($query){
			echo ' data saved';
		}
	else{
		echo 'there is an error';
	}
	
	
}	
}
	?>
<html>
<head>

<title>         Let Us Begin To Know You         </title>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/webcamjs/1.0.25/webcam.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">


</head>
<body>

<h2 style="text-align:center;">            Let Us Build Your Work Card                                     </h2>
<div style="width:50%;margin-left:150px;">
<form action="" method="post">
<div class="form-group">
<label>       Profession              </label> <br>
<input type="text" class="form-control " placeholder="Enter Your Profession" name="profession" required >
<br>

<label>       Organization               </label> <br>
<input type="text" name="organization"   placeholder="Enter Your Current Organization" class="form-control " required >
<br>
<label>         Location           </label> <br>
<input type="text" name="location"   placeholder="Enter Your Location" class="form-control " required >
<br>

<label>       Designation </label> <br>
<input type="text" name="designation"  class="form-control "  placeholder="Enter Your Designation" required >
<br>
<label>     Income          </label> <br>
<input type="text" name="income"  class="form-control "  pattern="[0-9]{10}" placeholder="Enter Your income" required >

<br>
<label>     Any Other Details          </label> <br>
<input type="text" name="other"  class="form-control "  placeholder="Other Details Not Required" >

<br>
<center><input type="submit" class="btn btn-info" name="submit"  value="Next"> </center>
</div>







</form>
</div>

</body>
</html>
