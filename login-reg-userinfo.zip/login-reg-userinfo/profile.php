<?php
session_start();
include('config.php');
// Validating Session
if(strlen($_SESSION['userlogin'])==0)
{
header('location:index.php');
}

?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  max-width: 300px;
  
  margin: auto;
  text-align: center;
  font-family: arial;
}

.title {
  color: grey;
  font-size: 18px;
}

button {
  border: none;
  outline: 0;
  display: inline-block;
  padding: 8px;
  color: white;
  background-color: #000;
  text-align: center;
  cursor: pointer;
  width: 100%;
  font-size: 18px;
}

a {
  text-decoration: none;
  font-size: 22px;
  margin-left:10px;
  color: black;
}

button:hover, a:hover {
  opacity: 0.7;
}
ul#menu li {
  display:inline;
  margin-left:5px;
  font-size:16px;
  
  
}


</style>
</head>
<body>
<?php

$username=$_SESSION['userlogin'];
$query=$dbh->prepare("SELECT * FROM userdata WHERE (UserName=:username || UserEmail=:username)");
      $query->execute(array(':username'=> $username));
       while($row=$query->fetch(PDO::FETCH_ASSOC)){
        $fullname=$row['FullName'];
		 $username=$row['UserName'];
		 $r= $row['users_uploadedpic'];
       }
       ?>
<?php

$username=$_SESSION['userlogin'];
$query=$dbh->prepare("SELECT * FROM userinfo WHERE user_login=:username");
      $query->execute(array(':username'=> $username));
       while($row=$query->fetch(PDO::FETCH_ASSOC)){
        $hometown=$row['hometown'];
		 
       }
       ?>	  
<h2 style="text-align:center"><?php echo $username; ?> Profile Card</h2>

<div class="card">
   <h3><?php echo $fullname ;   ?></h3>
   <p><?php echo $hometown; ?> </p>

  <img  src="snapshot/<?php echo (!empty($r)) ?  $r : 'avatar.png'; ?>" alt="John"  style="width:100%;height:300px;">
  <br>
    <a href="snapshot/upload_pic.php" class="btn btn-primary a-btn-slide-text">
        <span class="glyphicon glyphicon-edit" aria-hidden="true"></span>
        <span><strong>change</strong></span>            
    </a>
     <ul id="menu">
  <li>Height</li>
  <li>Drink</li>
  <li> Smoke</li>
  <li>Smokeup</li>
</ul>
 
  <div style="margin: 10px;">
   
    <a href="#"><i class="fa fa-twitter"></i></a>  
    <a href="#"><i class="fa fa-linkedin"></i></a>  
    <a href="#"><i class="fa fa-facebook"></i></a> 
  </div>
  <p><button>Enter Your Availablity</button></p>
</div>

</body>
</html>
